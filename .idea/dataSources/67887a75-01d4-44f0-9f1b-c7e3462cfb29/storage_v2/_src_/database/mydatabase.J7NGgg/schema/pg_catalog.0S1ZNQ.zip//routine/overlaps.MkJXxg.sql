create function "overlaps"(timestamp without time zone, timestamp without time zone, timestamp without time zone, interval) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function "overlaps"(timestamp, timestamp, timestamp, interval) owner to postgres;

