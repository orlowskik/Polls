create function lpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function lpad(text, integer) owner to postgres;

